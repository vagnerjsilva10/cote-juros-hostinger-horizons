
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, ShieldCheck, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';

function Footer() {
  const currentYear = new Date().getFullYear();

  const footerSections = [
    {
      title: 'Produtos',
      links: [
        { label: 'Comparador de empréstimos', path: '/emprestimos' },
        { label: 'Cartões', path: '/cartoes-de-credito' },
        { label: 'Financiamentos', path: '/financiamento' },
        { label: 'Ferramentas', path: '/ferramentas' }
      ]
    },
    {
      title: 'Conteúdo',
      links: [
        { label: 'Melhores empréstimos', path: '/melhores-emprestimos' },
        { label: 'Melhores cartões', path: '/melhores-cartoes' },
        { label: 'Simuladores', path: '/ferramentas' },
        { label: 'Educação financeira', path: '/blog' }
      ]
    },
    {
      title: 'Empresa',
      links: [
        { label: 'Sobre Cote Juros', path: '/sobre-nos' },
        { label: 'Blog', path: '/blog' },
        { label: 'Contato', path: '/contato' },
        { label: 'Carreiras', path: '/sobre-nos' }
      ]
    },
    {
      title: 'Legal',
      links: [
        { label: 'Política de privacidade', path: '/politica-de-privacidade' },
        { label: 'Termos de uso', path: '/termos-de-uso' },
        { label: 'Aviso de segurança', path: '/politica-de-privacidade' },
        { label: 'LGPD', path: '/politica-de-privacidade' }
      ]
    }
  ];

  return (
    <footer className="bg-[#0F172A] text-slate-300 border-t border-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          <div className="lg:col-span-2 space-y-6">
            <Link to="/" className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-[var(--radius-md)] gradient-fintech">
                <span className="text-xl font-bold text-white">CJ</span>
              </div>
              <span className="text-2xl font-extrabold text-white tracking-tight">Cote Juros</span>
            </Link>
            <p className="text-slate-400 leading-relaxed max-w-sm">
              Comparador financeiro inteligente. Encontre as melhores taxas de empréstimos, cartões e financiamentos do mercado em segundos.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg py-2 px-3 border border-slate-700">
                <ShieldCheck className="w-5 h-5 text-success" />
                <span className="text-xs font-semibold text-slate-200">Site Seguro</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800/50 rounded-lg py-2 px-3 border border-slate-700">
                <Lock className="w-5 h-5 text-primary" />
                <span className="text-xs font-semibold text-slate-200">LGPD</span>
              </div>
            </div>
          </div>
          
          {footerSections.map((section) => (
            <div key={section.title}>
              <span className="text-sm font-bold text-white uppercase tracking-wider mb-6 block">
                {section.title}
              </span>
              <ul className="space-y-4">
                {section.links.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-sm text-slate-400 hover:text-white transition-colors duration-200"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
          <div className="flex flex-col items-center md:items-start space-y-2">
            <p className="text-sm text-slate-400">
              Cote Juros © {currentYear}. Todos os direitos reservados.
            </p>
            <p className="text-xs text-slate-500">
              CNPJ: 00.000.000/0001-00 • São Paulo, SP - Brasil
            </p>
          </div>

          <div className="flex items-center space-x-2 bg-slate-800/30 px-4 py-2 rounded-full border border-slate-800">
            <Lock className="w-3 h-3 text-slate-400" />
            <span className="text-xs text-slate-400">Seus dados são protegidos com criptografia SSL</span>
          </div>

          <div className="flex items-center space-x-5">
            <a href="#" className="text-slate-400 hover:text-white transition-colors duration-200" aria-label="LinkedIn">
              <Linkedin className="h-5 w-5" />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors duration-200" aria-label="Twitter">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-slate-400 hover:text-white transition-colors duration-200" aria-label="Instagram">
              <Instagram className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
