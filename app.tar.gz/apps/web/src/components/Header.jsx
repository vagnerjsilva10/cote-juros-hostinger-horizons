
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ShieldCheck } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

function Header() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'Empréstimos', path: '/emprestimos' },
    { label: 'Cartões', path: '/cartoes-de-credito' },
    { label: 'Financiamentos', path: '/financiamento' },
    { label: 'Ferramentas', path: '/ferramentas' },
    { label: 'Blog', path: '/blog' }
  ];

  const isActive = (path) => {
    if (path === '/' && location.pathname !== '/') return false;
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/90 backdrop-blur-md shadow-sm transition-all duration-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <Link to="/" className="flex items-center space-x-3 interactive-element hover:opacity-80">
            <div className="flex items-center justify-center w-10 h-10 rounded-[var(--radius-md)] gradient-fintech shadow-[var(--shadow-sm)]">
              <span className="text-xl font-bold text-white">CJ</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-extrabold text-foreground leading-none tracking-tight">Cote Juros</span>
              <span className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider flex items-center mt-0.5">
                <ShieldCheck className="w-3 h-3 mr-1 text-success" /> Seguro
              </span>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center space-x-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-2 text-sm font-semibold rounded-[var(--radius-md)] interactive-element ${
                  isActive(item.path)
                    ? 'text-primary bg-primary/10'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <Link to="/diagnostico-financeiro">
              <Button className="gradient-fintech-hover text-white border-0 shadow-[var(--shadow-sm)] rounded-[var(--radius-md)] px-6 interactive-element active:scale-[0.98]">
                Analisar Perfil
              </Button>
            </Link>
          </div>

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="rounded-[var(--radius-md)]">
                <Menu className="h-6 w-6 text-foreground" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] border-l border-border bg-background">
              <div className="flex flex-col space-y-6 mt-8">
                <div className="flex items-center space-x-3 pb-6 border-b border-border">
                  <div className="w-8 h-8 rounded-[var(--radius-sm)] gradient-fintech flex items-center justify-center">
                    <span className="text-sm font-bold text-white">CJ</span>
                  </div>
                  <span className="text-lg font-bold text-foreground">Menu</span>
                </div>
                <nav className="flex flex-col space-y-2">
                  {navItems.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMobileOpen(false)}
                      className={`px-4 py-3 text-base font-semibold rounded-[var(--radius-md)] interactive-element ${
                        isActive(item.path)
                          ? 'text-primary bg-primary/10'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                      }`}
                    >
                      {item.label}
                    </Link>
                  ))}
                  <div className="pt-6 mt-4 border-t border-border">
                    <Link to="/diagnostico-financeiro" onClick={() => setMobileOpen(false)}>
                      <Button className="w-full gradient-fintech-hover text-white border-0 shadow-[var(--shadow-md)] rounded-[var(--radius-md)] h-12 text-base">
                        Analisar Perfil Grátis
                      </Button>
                    </Link>
                  </div>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export default Header;
