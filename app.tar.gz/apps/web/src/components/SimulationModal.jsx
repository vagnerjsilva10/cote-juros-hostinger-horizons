
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ArrowRight, ChevronLeft, ShieldCheck, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function SimulationModal({ isOpen, onClose }) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({
    valor: 10000,
    renda: 5000,
    score: '',
    dividas: null,
    cpf: '',
    terms: false
  });
  
  const navigate = useNavigate();

  const handleNext = () => setStep(s => Math.min(s + 1, 5));
  const handlePrev = () => setStep(s => Math.max(s - 1, 1));

  const formatCPF = (val) => {
    let v = val.replace(/\D/g, '').slice(0, 11);
    if (v.length > 9) v = v.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    else if (v.length > 6) v = v.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
    else if (v.length > 3) v = v.replace(/(\d{3})(\d{1,3})/, "$1.$2");
    setData({ ...data, cpf: v });
  };

  const handleComplete = () => {
    onClose();
    // In a real app, we'd pass data via state management or route state
    navigate('/diagnostico-financeiro');
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-xl p-0 overflow-hidden bg-white border-0 rounded-[var(--radius-lg)] shadow-[var(--shadow-lg)]">
        <DialogTitle className="sr-only">Simulação Financeira</DialogTitle>
        <DialogDescription className="sr-only">Preencha seus dados para receber ofertas.</DialogDescription>
        
        <div className="bg-slate-50 px-6 py-4 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            {step > 1 && (
              <button onClick={handlePrev} className="text-muted-foreground hover:text-foreground interactive-element">
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            <span className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
              Passo {step} de 5
            </span>
          </div>
          <div className="flex gap-1">
            {[1,2,3,4,5].map(i => (
              <div key={i} className={`h-1.5 w-8 rounded-full ${i <= step ? 'bg-primary' : 'bg-slate-200'} transition-colors duration-300`} />
            ))}
          </div>
        </div>

        <div className="p-8 sm:p-12 relative min-h-[400px] flex flex-col justify-center bg-white">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="w-full"
            >
              {step === 1 && (
                <div className="space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-extrabold text-foreground">Qual valor você precisa?</h2>
                    <p className="text-muted-foreground">Deslize para escolher o valor ideal.</p>
                  </div>
                  <div className="text-5xl font-extrabold text-primary text-center py-6 font-variant-tabular">
                    R$ {data.valor.toLocaleString('pt-BR')}
                  </div>
                  <Slider 
                    value={[data.valor]} 
                    onValueChange={v => setData({...data, valor: v[0]})} 
                    max={500000} 
                    min={1000} 
                    step={1000} 
                    className="py-4"
                  />
                  <Button className="w-full h-14 text-lg rounded-[var(--radius-md)] gradient-fintech-hover border-0 text-white shadow-[var(--shadow-md)]" onClick={handleNext}>
                    Próximo <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-extrabold text-foreground">Qual sua renda mensal?</h2>
                    <p className="text-muted-foreground">Isso nos ajuda a encontrar parcelas que cabem no seu bolso.</p>
                  </div>
                  <div className="text-5xl font-extrabold text-primary text-center py-6 font-variant-tabular">
                    R$ {data.renda.toLocaleString('pt-BR')}
                  </div>
                  <Slider 
                    value={[data.renda]} 
                    onValueChange={v => setData({...data, renda: v[0]})} 
                    max={50000} 
                    min={1000} 
                    step={500} 
                    className="py-4"
                  />
                  <Button className="w-full h-14 text-lg rounded-[var(--radius-md)] gradient-fintech-hover border-0 text-white shadow-[var(--shadow-md)]" onClick={handleNext}>
                    Próximo <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-extrabold text-foreground">Qual seu score aproximado?</h2>
                    <p className="text-muted-foreground">Sua pontuação nos birôs de crédito.</p>
                  </div>
                  <div className="grid gap-4">
                    {[
                      { id: 'Baixo', range: '300-549', color: 'border-destructive/50 hover:border-destructive hover:bg-destructive/5' },
                      { id: 'Médio', range: '550-749', color: 'border-warning/50 hover:border-warning hover:bg-warning/5' },
                      { id: 'Alto', range: '750-1000', color: 'border-success/50 hover:border-success hover:bg-success/5' }
                    ].map(s => (
                      <div 
                        key={s.id} 
                        onClick={() => { setData({...data, score: s.id}); setTimeout(handleNext, 300); }}
                        className={`p-5 rounded-[var(--radius-md)] border-2 cursor-pointer transition-all duration-200 flex justify-between items-center ${data.score === s.id ? 'ring-2 ring-primary border-primary bg-primary/5' : s.color}`}
                      >
                        <div>
                          <p className="font-bold text-lg text-foreground">{s.id}</p>
                          <p className="text-sm text-muted-foreground">{s.range} pontos</p>
                        </div>
                        {data.score === s.id && <CheckCircle2 className="text-primary w-6 h-6" />}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-extrabold text-foreground">Você possui dívidas em aberto?</h2>
                    <p className="text-muted-foreground">Contas atrasadas ou nome negativado.</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div 
                      onClick={() => { setData({...data, dividas: true}); setTimeout(handleNext, 300); }}
                      className={`p-8 rounded-[var(--radius-md)] border-2 cursor-pointer transition-all duration-200 text-center flex flex-col items-center gap-3 ${data.dividas === true ? 'ring-2 ring-primary border-primary bg-primary/5' : 'border-border hover:border-destructive/50 hover:bg-destructive/5'}`}
                    >
                      <XCircle className={`w-10 h-10 ${data.dividas === true ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="font-bold text-lg text-foreground">Sim</span>
                    </div>
                    <div 
                      onClick={() => { setData({...data, dividas: false}); setTimeout(handleNext, 300); }}
                      className={`p-8 rounded-[var(--radius-md)] border-2 cursor-pointer transition-all duration-200 text-center flex flex-col items-center gap-3 ${data.dividas === false ? 'ring-2 ring-primary border-primary bg-primary/5' : 'border-border hover:border-success/50 hover:bg-success/5'}`}
                    >
                      <CheckCircle2 className={`w-10 h-10 ${data.dividas === false ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="font-bold text-lg text-foreground">Não</span>
                    </div>
                  </div>
                </div>
              )}

              {step === 5 && (
                <div className="space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-extrabold text-foreground">Quase lá!</h2>
                    <p className="text-muted-foreground">Insira seu CPF para ver ofertas reais.</p>
                  </div>
                  
                  <div className="space-y-4">
                    <Input 
                      placeholder="000.000.000-00" 
                      value={data.cpf}
                      onChange={(e) => formatCPF(e.target.value)}
                      className="h-16 text-2xl text-center font-bold tracking-wider rounded-[var(--radius-md)]"
                    />
                    
                    <div className="bg-slate-50 p-4 rounded-[var(--radius-md)] flex items-start gap-3 border border-border">
                      <ShieldCheck className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Seus dados são criptografados. Usamos seu CPF apenas para simulação e não fazemos consultas que reduzam seu Score (Soft Query).
                      </p>
                    </div>

                    <div className="flex items-center space-x-2 pt-2">
                      <Checkbox 
                        id="terms" 
                        checked={data.terms} 
                        onCheckedChange={(c) => setData({...data, terms: c})} 
                      />
                      <label htmlFor="terms" className="text-sm font-medium leading-none text-muted-foreground cursor-pointer">
                        Concordo com os Termos de Uso e Política de Privacidade.
                      </label>
                    </div>
                  </div>

                  <Button 
                    className="w-full h-14 text-lg rounded-[var(--radius-md)] gradient-fintech-hover border-0 text-white shadow-[var(--shadow-md)]" 
                    disabled={data.cpf.length !== 14 || !data.terms}
                    onClick={handleComplete}
                  >
                    Ver ofertas personalizadas <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              )}

            </motion.div>
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default SimulationModal;
