
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SimulationModal } from '@/components/SimulationModal.jsx';
import { 
  Building2, Users, RefreshCw, ShieldCheck, Star, 
  ArrowRight, CreditCard, DollarSign, Home 
} from 'lucide-react';

function HomePage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [heroValue, setHeroValue] = useState('');

  const formatCurrency = (val) => {
    let v = val.replace(/\D/g, '');
    if (v) {
      v = (parseInt(v, 10) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    }
    setHeroValue(v);
  };

  const handleHeroSubmit = (e) => {
    e.preventDefault();
    setModalOpen(true);
  };

  const testimonials = [
    {
      name: 'João Silva',
      location: 'São Paulo, SP',
      product: 'Financiamento',
      avatar: 'https://ui-avatars.com/api/?name=Joao+Silva&background=0F62FE&color=fff',
      quote: 'Economizei mais de R$ 500 por mês no meu financiamento comparando as taxas aqui. O processo foi super rápido e transparente.'
    },
    {
      name: 'Maria Santos',
      location: 'Rio de Janeiro, RJ',
      product: 'Cartão de Crédito',
      avatar: 'https://ui-avatars.com/api/?name=Maria+Santos&background=7C3AED&color=fff',
      quote: 'Encontrei um cartão sem anuidade com ótimo limite e cashback. Antes eu pagava taxas abusivas sem saber das opções.'
    },
    {
      name: 'Carlos Oliveira',
      location: 'Belo Horizonte, MG',
      product: 'Empréstimo Pessoal',
      avatar: 'https://ui-avatars.com/api/?name=Carlos+Oliveira&background=14B8A6&color=fff',
      quote: 'Estava negativado e achei que não conseguiria crédito. A plataforma me mostrou opções reais que couberam no meu bolso.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Cote Juros - Comparador Financeiro Premium</title>
        <meta name="description" content="Compare empréstimos, cartões e financiamentos em segundos e encontre a melhor oferta para seu perfil." />
      </Helmet>

      <SimulationModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-foreground">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F62FE]/90 to-[#7C3AED]/90 mix-blend-multiply z-10" />
          <img
            src="https://images.unsplash.com/photo-1623141629340-4686d65d60bc?auto=format&fit=crop&w=2000&q=80"
            alt="Pessoas felizes usando celular"
            className="w-full h-full object-cover opacity-40 mix-blend-overlay"
          />
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-20">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-tight tracking-tight text-balance">
                Cote juros antes de pegar crédito.
              </h1>
              <p className="text-xl md:text-2xl text-white/90 mb-10 leading-relaxed max-w-3xl mx-auto font-medium">
                Compare empréstimos, cartões e financiamentos em segundos e encontre a melhor oferta para seu perfil.
              </p>
              
              <div className="bg-white p-4 rounded-[var(--radius-lg)] shadow-[var(--shadow-lg)] max-w-2xl mx-auto flex flex-col sm:flex-row gap-3 transform hover:scale-[1.01] transition-transform duration-300">
                <form onSubmit={handleHeroSubmit} className="flex-1 flex flex-col sm:flex-row gap-3 w-full">
                  <div className="relative flex-1">
                    <Input 
                      placeholder="De quanto você precisa? (R$)"
                      className="h-14 text-lg pl-4 bg-slate-50 border-slate-200 text-foreground rounded-[var(--radius-md)] focus-visible:ring-primary"
                      value={heroValue}
                      onChange={(e) => formatCurrency(e.target.value)}
                    />
                  </div>
                  <Button type="submit" className="h-14 px-8 text-lg font-bold rounded-[var(--radius-md)] gradient-fintech-hover border-0 text-white w-full sm:w-auto">
                    Simular agora
                  </Button>
                </form>
              </div>
              <p className="text-sm text-white/70 mt-4 flex items-center justify-center gap-2">
                <ShieldCheck className="w-4 h-4 text-success" /> Simulação 100% gratuita e segura
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-card border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-10">
            {[
              { icon: Building2, title: '50+ instituições analisadas', color: 'text-primary', bg: 'bg-primary/10' },
              { icon: Users, title: 'Milhares de simulações', color: 'text-secondary', bg: 'bg-secondary/10' },
              { icon: RefreshCw, title: 'Taxas atualizadas diariamente', color: 'text-accent', bg: 'bg-accent/10' },
              { icon: ShieldCheck, title: 'Segurança de dados garantida', color: 'text-success', bg: 'bg-success/10' }
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center text-center space-y-3">
                <div className={`w-14 h-14 rounded-full ${item.bg} flex items-center justify-center`}>
                  <item.icon className={`w-7 h-7 ${item.color}`} />
                </div>
                <span className="font-bold text-foreground text-sm md:text-base leading-snug max-w-[150px]">{item.title}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Comparisons */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-extrabold mb-4 text-foreground">Tudo para sua vida financeira</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Soluções inteligentes para economizar tempo e dinheiro.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Link to="/emprestimos" className="group">
              <Card className="card-premium h-full overflow-hidden border-0 bg-slate-50 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl -mr-10 -mt-10 transition-all group-hover:bg-primary/20" />
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-[var(--radius-md)] gradient-fintech flex items-center justify-center mb-6 shadow-[var(--shadow-sm)]">
                    <DollarSign className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-primary transition-colors">Empréstimos</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    Compare taxas de crédito pessoal, consignado e com garantia nas principais instituições.
                  </p>
                  <span className="font-semibold text-primary flex items-center">
                    Comparar ofertas <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </span>
                </CardContent>
              </Card>
            </Link>

            <Link to="/cartoes-de-credito" className="group">
              <Card className="card-premium h-full overflow-hidden border-0 bg-slate-50 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/10 rounded-full blur-2xl -mr-10 -mt-10 transition-all group-hover:bg-secondary/20" />
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-[var(--radius-md)] bg-secondary flex items-center justify-center mb-6 shadow-[var(--shadow-sm)]">
                    <CreditCard className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-secondary transition-colors">Cartões de Crédito</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    Filtre por benefícios como milhas, cashback ou ausência de anuidade e peça o seu.
                  </p>
                  <span className="font-semibold text-secondary flex items-center">
                    Ver melhores cartões <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </span>
                </CardContent>
              </Card>
            </Link>

            <Link to="/financiamento" className="group">
              <Card className="card-premium h-full overflow-hidden border-0 bg-slate-50 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-2xl -mr-10 -mt-10 transition-all group-hover:bg-accent/20" />
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-[var(--radius-md)] bg-accent flex items-center justify-center mb-6 shadow-[var(--shadow-sm)]">
                    <Home className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold mb-3 text-foreground group-hover:text-accent transition-colors">Financiamentos</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    Simule a compra da casa própria ou veículo com as menores taxas do mercado.
                  </p>
                  <span className="font-semibold text-accent flex items-center">
                    Simular parcelas <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </span>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Cote Finance AI Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 gradient-accent opacity-10" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-foreground rounded-[var(--radius-lg)] p-8 md:p-16 overflow-hidden relative shadow-[var(--shadow-lg)]">
            <div className="absolute -right-20 -top-20 w-96 h-96 bg-secondary/30 rounded-full blur-[100px]" />
            <div className="absolute -left-20 -bottom-20 w-96 h-96 bg-accent/30 rounded-full blur-[100px]" />
            
            <div className="grid md:grid-cols-2 gap-12 items-center relative z-20">
              <div>
                <Badge className="bg-accent/20 text-accent hover:bg-accent/30 border-0 mb-4 px-3 py-1">Novo Recurso</Badge>
                <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6 leading-tight">
                  Cote Finance AI
                </h2>
                <p className="text-lg text-slate-300 mb-8 leading-relaxed">
                  Nossa inteligência artificial faz uma varredura completa no mercado cruzando os dados do seu perfil com mais de 50 instituições para encontrar ofertas com até 95% de chance de aprovação.
                </p>
                <Button size="lg" className="h-14 px-8 text-base gradient-fintech-hover border-0 text-white rounded-[var(--radius-md)] shadow-[var(--shadow-md)]" onClick={() => setModalOpen(true)}>
                  Analisar minhas finanças
                </Button>
              </div>
              <div className="hidden md:flex justify-end">
                <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80" alt="Data analysis" className="rounded-2xl shadow-2xl rotate-3 border-4 border-white/10" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-24 bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-extrabold mb-4 text-foreground">Milhares de histórias de sucesso</h2>
            <p className="text-lg text-muted-foreground">O que nossos usuários dizem sobre nós.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((t, i) => (
              <Card key={i} className="card-premium bg-white border-slate-100">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="flex items-center gap-1 mb-6">
                    {[1,2,3,4,5].map(star => <Star key={star} className="w-5 h-5 fill-warning text-warning" />)}
                  </div>
                  <p className="text-foreground text-lg leading-relaxed mb-8 flex-1 italic font-medium">"{t.quote}"</p>
                  <div className="flex items-center gap-4 mt-auto pt-6 border-t border-slate-100">
                    <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-full shadow-sm" />
                    <div>
                      <p className="font-bold text-foreground">{t.name}</p>
                      <p className="text-sm text-muted-foreground">{t.location} • <span className="font-semibold text-primary">{t.product}</span></p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

    </>
  );
}

export default HomePage;
